// Traductor.h
// Provee la funcionalidad para solicitar traducciones a una API externa
// usando la clase Conexion y devolver únicamente la palabra traducida.
#ifndef TRADUCTOR_H
#define TRADUCTOR_H

#include <string>

class Conexion;

class Traductor {
private:
    Conexion* conexion;
    std::string endpoint; // endpoint de la API de traducción

public:
    Traductor(Conexion* conn, const std::string& apiEndpoint);

    // Traduce una palabra del español al inglés y devuelve la palabra traducida
    std::string traducir(const std::string& palabra) const;

    ~Traductor();
};

#endif // TRADUCTOR_H
