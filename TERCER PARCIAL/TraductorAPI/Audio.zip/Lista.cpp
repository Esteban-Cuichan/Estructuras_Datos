// Lista.cpp
// Implementación de la clase Lista: operaciones sobre la lista enlazada
// Insertar, mostrar, buscar, eliminar y liberar memoria dinámica.

#include "Lista.h"
#include <iostream>

Lista::Lista() : cabeza(nullptr) {}

// Insertar al final: se itera hasta el final y se añade el nuevo nodo
void Lista::insertar(const std::string& esp, const std::string& eng) {
    Nodo* nuevo = new Nodo(esp, eng);
    if (cabeza == nullptr) {
        cabeza = nuevo;
    } else {
        Nodo* actual = cabeza;
        while (actual->getSiguiente() != nullptr) {
            actual = actual->getSiguiente();
        }
        actual->setSiguiente(nuevo);
    }
}

// Muestra el historial completo
void Lista::mostrar() const {
    Nodo* actual = cabeza;
    if (actual == nullptr) {
        std::cout << "Historial vacío." << std::endl;
        return;
    }
    int index = 1;
    while (actual != nullptr) {
        std::cout << index << ". " << actual->getPalabraEspanol() << " -> "
                  << actual->getPalabraIngles() << std::endl;
        actual = actual->getSiguiente();
        ++index;
    }
}

// Buscar por palabra en español
Nodo* Lista::buscar(const std::string& esp) const {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        if (actual->getPalabraEspanol() == esp) {
            return actual;
        }
        actual = actual->getSiguiente();
    }
    return nullptr;
}

// Eliminar la primera ocurrencia de la palabra en español
bool Lista::eliminar(const std::string& esp) {
    Nodo* actual = cabeza;
    Nodo* anterior = nullptr;
    while (actual != nullptr) {
        if (actual->getPalabraEspanol() == esp) {
            if (anterior == nullptr) {
                // eliminar cabeza
                cabeza = actual->getSiguiente();
            } else {
                anterior->setSiguiente(actual->getSiguiente());
            }
            delete actual;
            return true;
        }
        anterior = actual;
        actual = actual->getSiguiente();
    }
    return false;
}

// Liberar toda la memoria dinámica
void Lista::liberarMemoria() {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        Nodo* siguiente = actual->getSiguiente();
        delete actual;
        actual = siguiente;
    }
    cabeza = nullptr;
}

Lista::~Lista() {
    liberarMemoria();
}
