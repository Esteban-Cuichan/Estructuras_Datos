// Audio.cpp
// Implementación de la clase Audio: construye la URL para Google TTS,
// descarga el MP3 usando Conexion y lanza la reproducción en el sistema.

#include "Audio.h"
#include "Conexion.h"
#include <stdexcept>
#include <sstream>
#include <cstdlib>

Audio::Audio(Conexion* conn) : conexion(conn) {}

// Codificación muy sencilla para URLs (percent-encoding)
std::string Audio::urlEncode(const std::string& value) const {
    std::ostringstream escaped;
    escaped.fill('0');
    escaped << std::hex;

        for (char c : value) {
        // Alfanuméricos y algunos símbolos se dejan tal cual
            if (isalnum(static_cast<unsigned char>(c)) || c == '-' || c == '_' || c == '.' || c == '~') {
            escaped << c;
        } else if (c == ' ') {
            escaped << "%20";
        } else {
                // Representar el byte en hexadecimal con dos dígitos
                unsigned int byte = static_cast<unsigned char>(c);
                std::ostringstream hex;
                hex << std::uppercase << std::hex << (byte >> 4);
                hex << std::uppercase << std::hex << (byte & 0xF);
                std::string hs = hex.str();
                if (hs.size() < 2) hs = std::string("0") + hs;
                escaped << '%' << hs;
        }
    }

    return escaped.str();
}

bool Audio::reproducirTexto(const std::string& texto) const {
    if (!conexion) throw std::runtime_error("Conexion no inicializada en Audio");

    // Construir URL de Google Translate TTS
    std::string base = "https://translate.google.com/translate_tts?ie=UTF-8&tl=en&client=tw-ob&q=";
    std::string q = urlEncode(texto);
    std::string url = base + q;

    // Archivo temporal
    std::string archivo = "tts_output.mp3";

    bool ok = conexion->descargarArchivo(url, archivo);
    if (!ok) return false;

    // Reproducir el archivo: en Windows usar start, en Linux xdg-open
#ifdef _WIN32
    std::string comando = "start \"\" \"" + archivo + "\"";
#else
    std::string comando = "xdg-open \"" + archivo + "\" &";
#endif
    int rc = std::system(comando.c_str());
    (void)rc;
    return true;
}

Audio::~Audio() {}
