// Conexion.h
// Encapsula las operaciones HTTP usando libcurl: inicialización, envío
// de peticiones y descarga de recursos (por ejemplo MP3 para TTS).
#ifndef CONEXION_H
#define CONEXION_H

#include <string>

class Conexion {
public:
    // Constructor inicializa libcurl globalmente
    Conexion();

    // Envía una petición POST con JSON y devuelve la respuesta como cadena
    std::string postJson(const std::string& url, const std::string& jsonPayload);

    // Envía una petición GET y devuelve la respuesta como cadena
    std::string getUrl(const std::string& url);

    // Descarga un recurso (binario) desde una URL y lo guarda en la ruta indicada
    bool descargarArchivo(const std::string& url, const std::string& rutaDestino);

    // Destructor limpia libcurl global
    ~Conexion();
};

#endif // CONEXION_H
