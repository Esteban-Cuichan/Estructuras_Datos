// Traductor.cpp
// Implementa la clase Traductor: construye la petición a la API de traducción
// y extrae la traducción del JSON de respuesta.

#include "Traductor.h"
#include "Conexion.h"
#include <stdexcept>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>

Traductor::Traductor(Conexion* conn, const std::string& apiEndpoint)
    : conexion(conn), endpoint(apiEndpoint) {}

// Método auxiliar muy simple para extraer el valor de "translatedText" del JSON
// Esta función no usa librerías externas de JSON para mantener el proyecto
// independiente y ligero. Busca la clave conocida en la respuesta y extrae
// el valor entre comillas.
static std::string extraerTraducido(const std::string& json) {
    const std::string key1 = "translatedText";
    size_t pos = json.find(key1);
    if (pos == std::string::npos) {
        // En algunos endpoints la clave puede ser "translation" u otra; buscamos comillas
        size_t q1 = json.find('"');
        size_t q2 = std::string::npos;
        if (q1 != std::string::npos) q2 = json.find('"', q1 + 1);
        if (q1 != std::string::npos && q2 != std::string::npos && q2 > q1)
            return json.substr(q1 + 1, q2 - q1 - 1);
        return std::string();
    }
    // buscar ':' después de la clave
    size_t colon = json.find(':', pos);
    if (colon == std::string::npos) return std::string();
    // buscar la primera comilla después de ':'
    size_t start = json.find('"', colon);
    if (start == std::string::npos) return std::string();
    size_t end = json.find('"', start + 1);
    if (end == std::string::npos) return std::string();
    return json.substr(start + 1, end - start - 1);
}

std::string Traductor::traducir(const std::string& palabra) const {
    if (!conexion) throw std::runtime_error("Conexion no inicializada");

    // Construir payload JSON para LibreTranslate (ejemplo):
    // {"q":"hola","source":"es","target":"en","format":"text"}
    std::string payload = "{\"q\":\"" + palabra + "\",\"source\":\"es\",\"target\":\"en\",\"format\":\"text\"}";

    std::string respuesta;
    try {
        respuesta = conexion->postJson(endpoint, payload);
    } catch (...) {
        respuesta.clear();
    }

    // Extraer el texto traducido desde la respuesta JSON
    std::string traducido = extraerTraducido(respuesta);

    // Si no obtuvimos resultado, intentar con MyMemory (GET)
    if (traducido.empty()) {
        // pequeño url-encode
        auto urlencode = [](const std::string& value) {
            std::ostringstream escaped;
            escaped.fill('0');
            escaped << std::hex;
            for (unsigned char c : value) {
                if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
                    escaped << c;
                } else if (c == ' ') {
                    escaped << '+';
                } else {
                    escaped << '%' << std::uppercase << std::setw(2) << int(c) << std::nouppercase;
                }
            }
            return escaped.str();
        };

        try {
            std::string url = "https://api.mymemory.translated.net/get?q=" + urlencode(palabra) + "&langpair=es|en";
            std::string resp2 = conexion->getUrl(url);
            // extraer responseData.translatedText
            const std::string key = "translatedText";
            size_t pos = resp2.find(key);
            if (pos != std::string::npos) {
                size_t colon = resp2.find(':', pos);
                size_t start = resp2.find('"', colon);
                if (start != std::string::npos) {
                    size_t end = resp2.find('"', start + 1);
                    if (end != std::string::npos) {
                        traducido = resp2.substr(start + 1, end - start - 1);
                    }
                }
            }
        } catch (...) {
            // Silenciar, devolver vacío
        }
    }

    // Normalizar espacios y retornarlo
    traducido.erase(std::remove(traducido.begin(), traducido.end(), '\n'), traducido.end());
    return traducido;
}

Traductor::~Traductor() {}
