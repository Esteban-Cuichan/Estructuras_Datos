// Lista.h
// Definición de la clase Lista para administrar una lista simplemente enlazada
// que almacena traducciones (palabra en español y su traducción al inglés).
#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"

class Lista {
private:
    Nodo* cabeza; // puntero al primer nodo

public:
    // Constructor inicializa la lista vacía
    Lista();

    // Inserta una nueva traducción al final de la lista
    void insertar(const std::string& esp, const std::string& eng);

    // Muestra todo el historial de traducciones
    void mostrar() const;

    // Busca una traducción por palabra en español. Devuelve el puntero al nodo o nullptr
    Nodo* buscar(const std::string& esp) const;

    // Elimina la primera ocurrencia de la palabra en español. Devuelve true si se eliminó
    bool eliminar(const std::string& esp);

    // Libera toda la memoria dinámica asociada a la lista
    void liberarMemoria();

    // Destructor: asegura liberar la memoria
    ~Lista();
};

#endif // LISTA_H
