// Nodo.h
// Define la clase Nodo que representa un elemento de la lista enlazada.
// Cada nodo almacena la palabra en español, su traducción al inglés y
// un puntero al siguiente nodo en la lista.
#ifndef NODO_H
#define NODO_H

#include <string>

class Nodo {
private:
    std::string palabraEspanol;
    std::string palabraIngles;
    Nodo* siguiente;

public:
    // Constructor que inicializa las palabras y el puntero siguiente
    Nodo(const std::string& esp, const std::string& eng);

    // Getters
    std::string getPalabraEspanol() const;
    std::string getPalabraIngles() const;
    Nodo* getSiguiente() const;

    // Setters
    void setPalabraEspanol(const std::string& esp);
    void setPalabraIngles(const std::string& eng);
    void setSiguiente(Nodo* sig);

    // Destructor
    ~Nodo();
};

#endif // NODO_H
