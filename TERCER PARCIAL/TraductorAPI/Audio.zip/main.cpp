// main.cpp
// Punto de entrada del programa: muestra un menú para traducir palabras,
// gestionar el historial en una lista enlazada y reproducir pronunciaciones.
#include <iostream>
#include <string>
#include <exception>

#include "Lista.h"
#include "Conexion.h"
#include "Traductor.h"
#include "Audio.h"

int main() {
    std::cout << "==========================\n";
    std::cout << "TRADUCTOR ESPAÑOL - INGLÉS\n";
    std::cout << "==========================\n";

    // Crear objetos dinámicamente tal y como se requiere
    Conexion* conexion = nullptr;
    Traductor* traductor = nullptr;
    Audio* audio = nullptr;
    Lista* lista = nullptr;

    try {
        conexion = new Conexion();
        // Usamos libretranslate.de como endpoint público de ejemplo
        std::string endpoint = "https://libretranslate.de/translate";
        traductor = new Traductor(conexion, endpoint);
        audio = new Audio(conexion);
        lista = new Lista();
    } catch (const std::exception& ex) {
        std::cerr << "Error al inicializar componentes: " << ex.what() << std::endl;
        delete conexion;
        delete traductor;
        delete audio;
        delete lista;
        return 1;
    }

    bool running = true;
    while (running) {
        std::cout << "\nIngrese una palabra en español (o escriba 'menu' para opciones):\n";
        std::string palabra;
        std::getline(std::cin, palabra);
        if (palabra.empty()) continue;
        if (palabra == "menu") {
            int opcion = 0;
            while (true) {
                std::cout << "\nMENÚ\n";
                std::cout << "1. Traducir otra palabra\n";
                std::cout << "2. Mostrar historial\n";
                std::cout << "3. Buscar traducción\n";
                std::cout << "4. Eliminar traducción\n";
                std::cout << "5. Salir\n";
                std::cout << "Seleccione una opción: ";
                std::string linea;
                std::getline(std::cin, linea);
                if (linea.empty()) continue;
                try {
                    opcion = std::stoi(linea);
                } catch (...) {
                    std::cout << "Opción inválida." << std::endl;
                    continue;
                }

                if (opcion == 1) break; // volver a solicitar palabra
                else if (opcion == 2) {
                    lista->mostrar();
                } else if (opcion == 3) {
                    std::cout << "Ingrese palabra a buscar: ";
                    std::string clave;
                    std::getline(std::cin, clave);
                    if (clave.empty()) continue;
                    Nodo* res = lista->buscar(clave);
                    if (res) {
                        std::cout << res->getPalabraEspanol() << " -> " << res->getPalabraIngles() << std::endl;
                    } else {
                        std::cout << "No encontrada en el historial." << std::endl;
                    }
                } else if (opcion == 4) {
                    std::cout << "Ingrese palabra a eliminar: ";
                    std::string clave;
                    std::getline(std::cin, clave);
                    if (clave.empty()) continue;
                    bool ok = lista->eliminar(clave);
                    if (ok) std::cout << "Eliminado." << std::endl;
                    else std::cout << "No encontrada." << std::endl;
                } else if (opcion == 5) {
                    running = false;
                    break;
                } else {
                    std::cout << "Opción inválida." << std::endl;
                }
            }
            if (!running) break;
            continue;
        }

        try {
            std::cout << "\nConsultando traducción...\n";
            std::string traducido = traductor->traducir(palabra);
            if (traducido.empty()) {
                std::cout << "No se obtuvo traducción." << std::endl;
            } else {
                std::cout << "Traducción:\n" << traducido << std::endl;
                lista->insertar(palabra, traducido);

                std::cout << "Reproduciendo pronunciación...\n";
                bool okAudio = audio->reproducirTexto(traducido);
                if (!okAudio) std::cout << "No se pudo reproducir audio." << std::endl;
            }
        } catch (const std::exception& ex) {
            std::cerr << "Error durante la traducción o reproducción: " << ex.what() << std::endl;
        }
    }

    // Al salir, liberar toda la memoria dinámica
    if (lista) {
        lista->liberarMemoria();
    }
    delete lista;
    delete audio;
    delete traductor;
    delete conexion;

    std::cout << "Saliendo. Memoria liberada." << std::endl;
    return 0;
}
