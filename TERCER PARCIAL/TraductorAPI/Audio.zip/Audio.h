// Audio.h
// Clase responsable de generar la URL de Google TTS, descargar el archivo MP3
// y reproducirlo automáticamente en el sistema.
#ifndef AUDIO_H
#define AUDIO_H

#include <string>

class Conexion;

class Audio {
private:
    Conexion* conexion;

    // Codifica una cadena para incluirla en una URL (percent-encoding)
    std::string urlEncode(const std::string& value) const;

public:
    Audio(Conexion* conn);

    // Construye la URL TTS, descarga el MP3 y lo reproduce. Devuelve true si tuvo éxito.
    bool reproducirTexto(const std::string& texto) const;

    ~Audio();
};

#endif // AUDIO_H
