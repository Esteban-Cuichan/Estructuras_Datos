// Nodo.cpp
// Implementación de la clase Nodo que guarda una traducción.
// Contiene métodos para acceder y modificar los campos y el puntero siguiente.
#include "Nodo.h"

// Constructor: copia las cadenas y establece siguiente en nullptr
Nodo::Nodo(const std::string& esp, const std::string& eng)
    : palabraEspanol(esp), palabraIngles(eng), siguiente(nullptr) {}

// Getters
std::string Nodo::getPalabraEspanol() const { return palabraEspanol; }
std::string Nodo::getPalabraIngles() const { return palabraIngles; }
Nodo* Nodo::getSiguiente() const { return siguiente; }

// Setters
void Nodo::setPalabraEspanol(const std::string& esp) { palabraEspanol = esp; }
void Nodo::setPalabraIngles(const std::string& eng) { palabraIngles = eng; }
void Nodo::setSiguiente(Nodo* sig) { siguiente = sig; }

// Destructor: no necesita liberar cadenas, pero incluimos para trazabilidad
Nodo::~Nodo() {}
