#include "Lista.h"
#include "Operaciones.h"
#include <iostream>

Lista::Lista(){
    this->cabeza=nullptr;
    this->cola=nullptr;
}

void Lista::insertar(string cedula,string nombre){
    Nodo* nuevo=new Nodo(cedula,nombre,nullptr);
    if(cabeza==nullptr){
        cabeza=nuevo;
        cola=nuevo;
    }else{
        nuevo->setSiguiente(cabeza);
        cabeza=nuevo;
    }
}

void Lista::imprimir(){
    if(cabeza==nullptr){
        cout<<"No se ha podido encontrar ningun dato ingresado!"<<endl;
        cout<<"LISTA VACÍA!"<<endl;
    }else{
        Nodo* aux=cabeza;
        cout<<"Lista de registros:"<<endl;
        while(aux!=nullptr){
            cout<<"Cedula: "<<aux->getCedula()<<"| Nombre: "<<aux->getNombre()<<endl;
            aux=aux->getSiguiente();
        }
    }
}

Nodo* Lista::buscar(string cedula){
    string cedula_buscar=cedula;
    Nodo* aux=cabeza;
    while(aux!=nullptr){
        if(aux->getCedula()==cedula_buscar){
            return aux;
        }else{
            aux=aux->getSiguiente();
        }
    }
    return nullptr;
}

void Lista::eliminar(string cedula){
    Nodo* actual=cabeza;
    Nodo* anterior=nullptr;
    while(actual!=nullptr){
        if(actual->getCedula()==cedula){
            if(actual==cabeza){
                cabeza=cabeza->getSiguiente();
            }else{
                anterior->setSiguiente(actual->getSiguiente());
            }
            if(actual==cola){
                cola=anterior;
            }
            delete actual;
            return;
        }
        anterior=actual;
        actual=actual->getSiguiente();
    }
    cout<<"No se encontro ningun dato que coincida!"<<endl;
}

int Lista::conteoNodos(char letra){
    int suma=0;
    Nodo* aux=cabeza;
    while(aux!=nullptr){
        if(aux->getNombre().front()==letra){
            suma++;
        }
        aux=aux->getSiguiente();
    }
    return suma;
}

Nodo* Lista::retornoPenultimo(){
    if(cabeza==nullptr || cabeza->getSiguiente()==nullptr) return nullptr;
    Nodo* aux=cabeza;
    while(aux->getSiguiente()->getSiguiente()!=nullptr){
        aux=aux->getSiguiente();
    }
    return aux->getSiguiente();
}

void Lista::eliminarPrimero(){
    if(cabeza!=nullptr){
        Nodo* aux=cabeza;
        cabeza=cabeza->getSiguiente();
        delete aux;
    }
}

void Lista::eliminarDuplicados(){
    if(cabeza==nullptr || cabeza->getSiguiente()==nullptr) return;
    Nodo* aux=cabeza;
    while(aux!=nullptr && aux->getSiguiente()!=nullptr){
        if(aux->getCedula()==aux->getSiguiente()->getCedula()){
            Nodo* duplicado=aux->getSiguiente();
            aux->setSiguiente(duplicado->getSiguiente());
            if(duplicado==cola){
                cola=aux;
            }
            delete duplicado;
        }else{
            aux=aux->getSiguiente();
        }
    }
}

void Lista::setCabeza(Nodo* cabeza){
    this->cabeza=cabeza;
}

void Lista::setCola(Nodo* cola){
    this->cola=cola;
}

Nodo* Lista::getCabeza(){
    return this->cabeza;
}

Nodo* Lista::getCola(){
    return this->cola;
}