#include "Operaciones.h"
#include <iostream>
#include "Nodo.h"
#include "Lista.h"

void Operaciones::insertar(string cedula, string nombre){
    Nodo* nuevo=new Nodo(cedula,nombre);
    if(Lista::getCabeza()==nullptr){
        
    }
}